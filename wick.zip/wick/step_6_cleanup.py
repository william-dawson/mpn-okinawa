"""
Step 6: Cleanup / Simplification with ERI Canonicalization

Two passes:
  1. Canonicalize each integral within each tensor (sort indices, apply sign).
  2. Collect terms by canonical form and sum their numerical factors.
  3. Drop any term whose total factor is (effectively) zero.

Canonicalization rules for <p,q||r,s>:
  - Sort bra (p,q) lexicographically, applying -1 if swapped
  - Sort ket (r,s) lexicographically, applying -1 if swapped
  - Sort left-right blocks lexicographically (no sign change for <||>)
"""

from __future__ import annotations
import re
from typing import List
from .term import Term, Tensor


_EPSILON = 1e-12


def _canonicalize_integral_indices(integral_str: str) -> tuple[str, int]:
    """
    Transform '<p,q||r,s>' into canonical form with sign.
    Returns (canonical_string, sign_change).
    """
    indices = re.findall(r'[a-z0-9]+', integral_str)
    if len(indices) != 4:
        return (integral_str, 1)

    p, q, r, s = indices
    sign = 1

    # Rule 1: sort bra (p,q)
    if p > q:
        p, q = q, p
        sign *= -1

    # Rule 2: sort ket (r,s)
    if r > s:
        r, s = s, r
        sign *= -1

    # Rule 3: sort left-right blocks (no sign change for <||>)
    if (p, q) > (r, s):
        p, q, r, s = r, s, p, q

    return (f"<{p},{q}||{r},{s}>", sign)


def _canonicalize_tensor(tensor: Tensor) -> tuple[Tensor, int]:
    """
    Canonicalize all 4-index integrals in a tensor.
    Returns (new_tensor, total_sign).
    """
    name = tensor.name
    indices = tensor.indices
    sign = 1

    if len(indices) == 4:
        integral_str = f"<{indices[0]},{indices[1]}||{indices[2]},{indices[3]}>"
        canon_str, s = _canonicalize_integral_indices(integral_str)
        sign *= s

        canon_indices = re.findall(r'[a-z0-9]+', canon_str)
        return (Tensor(name, canon_indices), sign)

    return (tensor, sign)


def _term_key(term: Term) -> tuple[tuple, int]:
    """
    Canonical key for a term with accumulated sign from canonicalization.
    Returns (canonical_tensor_key, total_sign).
    """
    canonical_tensors = []
    total_sign = 1

    for tensor in term.tensors:
        canon_tensor, s = _canonicalize_tensor(tensor)
        canonical_tensors.append(canon_tensor.to_string())
        total_sign *= s

    canonical_tensors.sort()
    return (tuple(canonical_tensors), total_sign)


def cancel_terms(terms: List[Term]) -> List[Term]:
    """Canonicalize integrals, sum identical terms, drop zeros."""
    buckets = {}   # key -> (running_factor, reference_term)

    for term in terms:
        key, canon_sign = _term_key(term)
        effective = term.effective_factor * canon_sign

        if key in buckets:
            buckets[key][0] += effective
        else:
            buckets[key] = [effective, term]

    result = []
    for total_factor, ref_term in buckets.values():
        if abs(total_factor) > _EPSILON:
            new_term = ref_term.copy()
            new_term.sign   = 1 if total_factor > 0 else -1
            new_term.factor = abs(total_factor)
            result.append(new_term)

    return result
