"""
Step 6a: Linked-Cluster Theorem Filter

Remove unlinked (disconnected) diagram contributions.

In MBPT, the linked-cluster theorem states that unlinked diagram contributions
to the energy cancel exactly. This is equivalent to intermediate normalization:
  ⟨Ψ⁰|Ψⁿ⟩ = 0

A diagram is LINKED if it contributes to correlation energy with the correct
intermediate excitation structure. For second-order (MP2), this means:
  - Exactly 2 occupied (hole) and 2 virtual (particle) indices
  - Denominator: (e_i + e_j - e_a - e_b)

A diagram is UNLINKED if it contains:
  - Separated, non-interacting sub-diagrams (e.g., two bubble insertions)
  - Incorrect number of holes/particles
  - Sign that indicates a disconnected piece

DIAGNOSTIC: Unlinked terms have denominators that don't match (occ - virt) structure.
"""

from __future__ import annotations
from typing import List
from .term import Term, is_occ, is_virt


def _is_bubble_diagram(term: Term) -> bool:
    """
    Check if a term represents a pure self-energy bubble (product of non-interacting pieces).

    A pure bubble is a product where BOTH tensors are "self-loops" with NO
    indices shared between them. Example: <i,j||i,j> * <k,l||k,l>

    This is an unlinked diagram (product of two independent contributions)
    and should be removed per linked-cluster theorem.

    Note: Exchanged forms like <i,j||j,i> * <k,l||k,l> are still considered
    pure bubbles because they represent the same physics (product of independent
    one-body contributions that should cancel).
    """
    if len(term.tensors) != 2:
        return False

    # Get all indices from both tensors
    all_indices = set()
    for tensor in term.tensors:
        all_indices.update(tensor.indices)

    # Check if indices are completely separated (no shared indices between the two ERIs)
    tensor1_indices = set(term.tensors[0].indices)
    tensor2_indices = set(term.tensors[1].indices)

    # True bubble: the two ERIs have completely disjoint index sets
    if tensor1_indices.isdisjoint(tensor2_indices):
        # Both ERIs are self-contracted (bubble-like)
        # Check that each is internally structured like <pq||pq> or <pq||qp>
        for tensor in term.tensors:
            p, q, r, s = tensor.indices
            eri_bra = set([p, q])
            eri_ket = set([r, s])
            if eri_bra != eri_ket:
                # Not a self-bubble
                return False
        # This is a pure product of two separate self-energies
        return True

    return False


def is_linked_diagram(term: Term) -> bool:
    """
    Check if a term represents a linked (connected) diagram.

    Per the linked-cluster theorem, remove:
    - Self-energy bubbles: terms where all ERIs are internally contracted
    - Other unlinked contributions

    Keep:
    - Terms with proper excitation structure (even if intermediate indices
      don't match the standard 2-occ-2-virt pattern, as they may contribute
      via partial cancellations)

    Returns True if diagram should be kept, False if it's a pure bubble.
    """
    # Reject pure bubble self-energies
    if _is_bubble_diagram(term):
        return False

    # Keep everything else (including mixed/unlinked terms that may
    # partially cancel with others)
    return True


def _is_brillouin_violation(term: Term) -> bool:
    """
    Check if a term has single-excitation character.

    Per Brillouin's theorem: ⟨Ψ⁰|H|Ψ¹⟩ = 0

    Terms with 3 occupied and 1 virtual index (or similar single-excitation
    patterns) are matrix elements between ground and singly-excited states
    and must vanish by orthogonality with Hartree-Fock.

    Example: <i,j||a,j> * <a,k||i,k> has indices {i,j,a,k} where:
      - Occupied: i, j, k (3 unique)
      - Virtual: a (1 unique)
    This is a single-excitation contribution and should be removed.
    """
    # Collect all unique indices
    all_indices = set()
    for tensor in term.tensors:
        all_indices.update(tensor.indices)

    # Count occupied vs virtual
    occ_indices = [idx for idx in all_indices if is_occ(idx)]
    virt_indices = [idx for idx in all_indices if is_virt(idx)]

    # Single-excitation pattern: 3 occ + 1 virt (or similar imbalance indicating
    # a term that couples ground to singly-excited manifold)
    if len(occ_indices) == 3 and len(virt_indices) == 1:
        return True
    if len(occ_indices) == 1 and len(virt_indices) == 3:
        return True

    return False


def filter_unlinked_diagrams(terms: List[Term]) -> List[Term]:
    """
    Remove unlinked diagram contributions via linked-cluster and Brillouin theorems.

    Removes:
      - Bubble diagrams (self-energy insertions) via linked-cluster theorem
      - Single-excitation contributions via Brillouin's theorem ⟨Ψ⁰|H|Ψ¹⟩ = 0

    Retains only terms with proper two-body excitation character.
    """
    result = []
    for term in terms:
        if _is_bubble_diagram(term):
            continue  # Remove bubbles
        if _is_brillouin_violation(term):
            continue  # Remove single-excitation contributions
        result.append(term)
    return result
